# JsonRpcDemo
Dubbo JsonRpc protocol demo server-side
### 使用
调用 com.ofpay.demo.Demo的main方法直接启动
